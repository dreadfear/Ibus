<!-- Shortcode -->
```
[select tinh_thanh id:tinh_thanh class:tinh_thanh]
[select quan_huyen id:quan_huyen class:quan_huyen]
[select phuong_xa id:phuong_xa class:phuong_xa]
```
add this to function.php
require get_template_directory() . '/lib/vietnam-address-cf7/vietnam-address-cf7/function.php';