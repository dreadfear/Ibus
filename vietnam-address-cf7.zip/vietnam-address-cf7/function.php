<?php
defined('ABSPATH') or die('No script kiddies please!');

/**
 * Helper
 */


function vn_address_search_in_array($array, $key, $value)
{
	$results = array();

	if (is_array($array)) {
		if (isset($array[$key]) && $array[$key] == $value) {
			$results[] = $array;
		} elseif (isset($array[$key]) && is_serialized($array[$key]) && in_array($value, maybe_unserialize($array[$key]))) {
			$results[] = $array;
		}
		foreach ($array as $subarray) {
			$results = array_merge($results, vn_address_search_in_array($subarray, $key, $value));
		}
	}

	return $results;
}

function sort_data($a, $b)
{
	return strnatcasecmp($a['name'], $b['name']);
}

/**
 * remove schema of CF7
 */

remove_action('wpcf7_swv_create_schema', 'wpcf7_swv_add_select_enum_rules', 20, 2);

/**
 * Data
 */
include 'data/tinh_thanhpho.php';
include 'data/quan_huyen.php';
include 'data/xa_phuong.php';

/**
 * Build Ajax
 */

add_action('wp_ajax_nopriv_province', 'vn_address_province');
add_action('wp_ajax_province', 'vn_address_province');

function vn_address_province()
{
	global $tinh_thanhpho;
	wp_send_json_success($tinh_thanhpho);
}


add_action('wp_ajax_nopriv_district', 'vn_address_district');
add_action('wp_ajax_district', 'vn_address_district');
function vn_address_district()
{
	global $quan_huyen;
	$province = $_POST['province'];
	$result = vn_address_search_in_array($quan_huyen, 'matp', $province);

	usort($result, function ($a, $b) {
		return strnatcasecmp($a['name'], $b['name']);
	});

	wp_send_json_success($result);
}

add_action('wp_ajax_nopriv_ward', 'vn_address_ward');
add_action('wp_ajax_ward', 'vn_address_ward');
function vn_address_ward()
{
	global $xa_phuong;
	$district = $_POST['district'];
	$result = vn_address_search_in_array($xa_phuong, 'maqh', $district);

	usort($result, function ($a, $b) {
		return strnatcasecmp($a['name'], $b['name']);
	});

	wp_send_json_success($result);
}
/**
 * Script
 */

add_action('wp_footer', function () {
?>
	<script>
		jQuery(document).ready(function($) {
			// Provinces
			$.ajax({
				url: '<?= admin_url('admin-ajax.php') ?>',
				type: 'POST',
				data: {
					action: 'province'
				},
				beforeSend: function() {
					$('#tinh_thanh').html('<option value=""><?= _e('Đang tải dữ liệu', 'canhcamtheme') ?>...</option>');
				},
				success: function(res) {
					const province = res.data;
					var html = `<option value="">Chọn tỉnh/thành phố</option>`;
					$.each(province, function(key, value) {
						html += `<option value="${value}" data-id="${key}">${value}</option>`;
					});
					$('#tinh_thanh').html(html);
				}
			})
			// Districts
			$(document).on('change', '#tinh_thanh', function() {
				const id = $(this).find(':selected').data('id');
				$.ajax({
					url: '<?= admin_url('admin-ajax.php') ?>',
					type: 'POST',
					data: {
						action: 'district',
						province: id
					},
					beforeSend: function() {
						$('#quan_huyen').html('<option value=""><?= _e('Đang tải dữ liệu', 'canhcamtheme') ?>...</option>');
						$('#phuong_xa').html('<option value=""><?= _e('Đang tải dữ liệu', 'canhcamtheme') ?>...</option>');
					},
					success: function(res) {
						const district = res.data;
						var html = `<option value="">Chọn quận/huyện</option>`;
						$.each(district, function(key, value) {
							html += `<option value="${value.name}" data-id="${value.maqh}">${value.name}</option>`;
						});
						$('#quan_huyen').html(html);
						$('#phuong_xa').html('<option value="">Chọn Phường/xã</option>');
					}
				})
			})
			// Wards
			$(document).on('change', '#quan_huyen', function() {
				const id = $(this).find(':selected').data('id');
				$.ajax({
					url: '<?= admin_url('admin-ajax.php') ?>',
					type: 'POST',
					data: {
						action: 'ward',
						district: id
					},
					beforeSend: function() {
						$('#phuong_xa').html('<option value=""><?= _e('Đang tải dữ liệu', 'canhcamtheme') ?>...</option>');
					},
					success: function(res) {
						const ward = res.data;
						var html = `<option value="">Chọn Phường/xã</option>`;
						$.each(ward, function(key, value) {
							html += `<option value="${value.name}" data-id="${value.xaid}">${value.name}</option>`;
						});
						$('#phuong_xa').html(html);
					}
				})
			})

		})
	</script>
<?php
})
?>